#pragma once
class InterFace {
public:
	static int event();
	static int saving();
};