#pragma once
#include "Shape.h"
class Line :public Shape {
	void paint(int count);
};