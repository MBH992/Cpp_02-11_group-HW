#pragma once
class Graphic_editer {
public:
	void run();
	void new_node();
	int delete_node();
	void show_nodes();
	void del(int n);
};