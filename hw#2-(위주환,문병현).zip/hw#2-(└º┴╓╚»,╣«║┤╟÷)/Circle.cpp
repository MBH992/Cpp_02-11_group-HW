#include<iostream>
#include "Circle.h"
using namespace std;
void Circle::paint(int count) {
	cout << count <<": Circle" << endl;
}