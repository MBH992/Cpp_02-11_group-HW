#pragma once
#include "Shape.h"
class Circle :public Shape {
	void paint(int count);
};