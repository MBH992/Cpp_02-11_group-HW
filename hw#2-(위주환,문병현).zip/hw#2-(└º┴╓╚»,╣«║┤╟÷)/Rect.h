#pragma once
#include "Shape.h"
class Rect :public Shape {
	void paint(int count);
};