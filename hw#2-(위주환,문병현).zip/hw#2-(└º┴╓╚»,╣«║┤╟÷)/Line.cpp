#include<iostream>
#include "Line.h"
using namespace std;
void Line::paint(int count) {
	cout << count << ": Line" << endl;
}