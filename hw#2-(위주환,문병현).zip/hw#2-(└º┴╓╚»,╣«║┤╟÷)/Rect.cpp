#include<iostream>
#include "Rect.h"
using namespace std;
void Rect::paint(int count) {
	cout << count << ": Rect" << endl;
}